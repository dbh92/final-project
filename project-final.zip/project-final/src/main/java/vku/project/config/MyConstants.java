package vku.project.config;

public class MyConstants {
    public static final String MY_EMAIL = "nhkhanh6398@gmail.com";


    public static final String MY_PASSWORD = "emnamruq";
}