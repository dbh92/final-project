package vku.project.service;

import vku.project.entity.AccountRole;

public interface AccountRoleService {
    void save(AccountRole accountRole);
}
