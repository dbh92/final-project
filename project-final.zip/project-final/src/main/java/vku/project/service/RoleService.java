package vku.project.service;

public interface RoleService {

}
